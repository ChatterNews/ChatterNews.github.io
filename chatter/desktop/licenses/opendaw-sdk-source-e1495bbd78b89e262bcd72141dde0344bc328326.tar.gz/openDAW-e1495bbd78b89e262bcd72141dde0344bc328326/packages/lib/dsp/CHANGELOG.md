# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.0.91](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.90...@opendaw/lib-dsp@0.0.91) (2026-08-17)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.90](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.88...@opendaw/lib-dsp@0.0.90) (2026-08-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.88](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.87...@opendaw/lib-dsp@0.0.88) (2026-07-15)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.87](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.86...@opendaw/lib-dsp@0.0.87) (2026-07-14)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.86](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.85...@opendaw/lib-dsp@0.0.86) (2026-07-07)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.85](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.84...@opendaw/lib-dsp@0.0.85) (2026-06-23)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.84](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.83...@opendaw/lib-dsp@0.0.84) (2026-05-22)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.83](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.82...@opendaw/lib-dsp@0.0.83) (2026-05-13)

**Note:** Version bump only for package @opendaw/lib-dsp

## 0.0.82 (2026-05-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.81](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.80...@opendaw/lib-dsp@0.0.81) (2026-04-22)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.80](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.79...@opendaw/lib-dsp@0.0.80) (2026-04-15)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.79](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.78...@opendaw/lib-dsp@0.0.79) (2026-04-01)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.78](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.77...@opendaw/lib-dsp@0.0.78) (2026-03-27)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.77](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.76...@opendaw/lib-dsp@0.0.77) (2026-03-10)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.76](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.75...@opendaw/lib-dsp@0.0.76) (2026-03-04)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.75](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.74...@opendaw/lib-dsp@0.0.75) (2026-03-03)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.74](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.73...@opendaw/lib-dsp@0.0.74) (2026-03-02)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.73](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.72...@opendaw/lib-dsp@0.0.73) (2026-02-25)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.72](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.71...@opendaw/lib-dsp@0.0.72) (2026-02-14)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.71](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.70...@opendaw/lib-dsp@0.0.71) (2026-02-12)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.70](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.69...@opendaw/lib-dsp@0.0.70) (2026-02-06)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.69](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.68...@opendaw/lib-dsp@0.0.69) (2026-02-03)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.68](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.67...@opendaw/lib-dsp@0.0.68) (2026-01-23)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.67](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.66...@opendaw/lib-dsp@0.0.67) (2026-01-20)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.66](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.65...@opendaw/lib-dsp@0.0.66) (2026-01-16)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.65](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.64...@opendaw/lib-dsp@0.0.65) (2026-01-13)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.64](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.63...@opendaw/lib-dsp@0.0.64) (2026-01-07)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.63](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.62...@opendaw/lib-dsp@0.0.63) (2026-01-06)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.62](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.61...@opendaw/lib-dsp@0.0.62) (2025-12-28)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.61](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.60...@opendaw/lib-dsp@0.0.61) (2025-12-17)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.60](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.59...@opendaw/lib-dsp@0.0.60) (2025-12-10)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.59](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.58...@opendaw/lib-dsp@0.0.59) (2025-12-10)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.58](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.57...@opendaw/lib-dsp@0.0.58) (2025-12-10)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.57](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.56...@opendaw/lib-dsp@0.0.57) (2025-12-10)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.56](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.55...@opendaw/lib-dsp@0.0.56) (2025-12-10)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.55](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.54...@opendaw/lib-dsp@0.0.55) (2025-12-09)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.54](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.53...@opendaw/lib-dsp@0.0.54) (2025-12-09)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.53](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.52...@opendaw/lib-dsp@0.0.53) (2025-12-04)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.52](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.51...@opendaw/lib-dsp@0.0.52) (2025-12-04)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.51](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.50...@opendaw/lib-dsp@0.0.51) (2025-12-04)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.50](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.49...@opendaw/lib-dsp@0.0.50) (2025-11-17)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.49](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.48...@opendaw/lib-dsp@0.0.49) (2025-11-17)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.48](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.47...@opendaw/lib-dsp@0.0.48) (2025-11-17)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.47](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.46...@opendaw/lib-dsp@0.0.47) (2025-10-30)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.46](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.45...@opendaw/lib-dsp@0.0.46) (2025-10-29)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.45](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.44...@opendaw/lib-dsp@0.0.45) (2025-10-29)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.44](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.43...@opendaw/lib-dsp@0.0.44) (2025-10-28)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.43](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.42...@opendaw/lib-dsp@0.0.43) (2025-10-28)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.42](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.41...@opendaw/lib-dsp@0.0.42) (2025-10-28)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.41](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.40...@opendaw/lib-dsp@0.0.41) (2025-10-27)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.40](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.39...@opendaw/lib-dsp@0.0.40) (2025-10-27)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.39](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.38...@opendaw/lib-dsp@0.0.39) (2025-10-24)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.38](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.37...@opendaw/lib-dsp@0.0.38) (2025-10-24)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.37](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.36...@opendaw/lib-dsp@0.0.37) (2025-10-23)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.36](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.35...@opendaw/lib-dsp@0.0.36) (2025-10-21)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.35](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.34...@opendaw/lib-dsp@0.0.35) (2025-10-16)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.34](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.33...@opendaw/lib-dsp@0.0.34) (2025-10-13)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.33](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.32...@opendaw/lib-dsp@0.0.33) (2025-10-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.32](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.31...@opendaw/lib-dsp@0.0.32) (2025-10-07)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.31](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.30...@opendaw/lib-dsp@0.0.31) (2025-10-07)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.30](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.29...@opendaw/lib-dsp@0.0.30) (2025-10-02)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.29](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.28...@opendaw/lib-dsp@0.0.29) (2025-10-01)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.28](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.27...@opendaw/lib-dsp@0.0.28) (2025-09-24)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.27](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.26...@opendaw/lib-dsp@0.0.27) (2025-09-15)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.26](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.25...@opendaw/lib-dsp@0.0.26) (2025-09-13)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.25](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.24...@opendaw/lib-dsp@0.0.25) (2025-09-06)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.24](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.23...@opendaw/lib-dsp@0.0.24) (2025-09-04)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.23](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.22...@opendaw/lib-dsp@0.0.23) (2025-09-04)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.22](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.21...@opendaw/lib-dsp@0.0.22) (2025-08-27)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.21](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.20...@opendaw/lib-dsp@0.0.21) (2025-08-27)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.20](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.19...@opendaw/lib-dsp@0.0.20) (2025-08-26)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.19](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.18...@opendaw/lib-dsp@0.0.19) (2025-07-25)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.18](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.17...@opendaw/lib-dsp@0.0.18) (2025-07-23)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.17](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.16...@opendaw/lib-dsp@0.0.17) (2025-07-22)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.16](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.15...@opendaw/lib-dsp@0.0.16) (2025-07-22)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.15](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.14...@opendaw/lib-dsp@0.0.15) (2025-07-22)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.14](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.13...@opendaw/lib-dsp@0.0.14) (2025-07-18)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.13](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.12...@opendaw/lib-dsp@0.0.13) (2025-07-17)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.12](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.11...@opendaw/lib-dsp@0.0.12) (2025-07-16)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.11](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.10...@opendaw/lib-dsp@0.0.11) (2025-07-16)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.10](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.9...@opendaw/lib-dsp@0.0.10) (2025-07-15)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.9](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.8...@opendaw/lib-dsp@0.0.9) (2025-07-15)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.8](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.7...@opendaw/lib-dsp@0.0.8) (2025-07-15)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.7](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.6...@opendaw/lib-dsp@0.0.7) (2025-07-15)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.6](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.5...@opendaw/lib-dsp@0.0.6) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.5](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.4...@opendaw/lib-dsp@0.0.5) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.4](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.3...@opendaw/lib-dsp@0.0.4) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.3](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.2...@opendaw/lib-dsp@0.0.3) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.2](https://github.com/andremichelle/openDAW/compare/@opendaw/lib-dsp@0.0.1...@opendaw/lib-dsp@0.0.2) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## 0.0.1 (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.5](https://github.com/andremichelle/opendaw-turbo/compare/@opendaw/lib-dsp@0.0.4...@opendaw/lib-dsp@0.0.5) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.4](https://github.com/andremichelle/opendaw-turbo/compare/@opendaw/lib-dsp@0.0.3...@opendaw/lib-dsp@0.0.4) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.3](https://github.com/andremichelle/opendaw-turbo/compare/@opendaw/lib-dsp@0.0.2...@opendaw/lib-dsp@0.0.3) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## [0.0.2](https://github.com/andremichelle/opendaw-turbo/compare/@opendaw/lib-dsp@0.0.1...@opendaw/lib-dsp@0.0.2) (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp

## 0.0.1 (2025-07-11)

**Note:** Version bump only for package @opendaw/lib-dsp
